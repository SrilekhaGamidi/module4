package com.cg.sbu;

import java.util.List;

public class SBUBean {
	private int sbuCode;
	private String sbuName;
	private String sbuHead;
	private List<EmployeeBean> employees;
	public int getSbuCode() {
		return sbuCode;
	}
	public void setSbuCode(int sbuCode) {
		this.sbuCode = sbuCode;
	}
	public String getSbuName() {
		return sbuName;
	}
	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}
	public String getSbuHead() {
		return sbuHead;
	}
	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}
	public List<EmployeeBean> getEmployees() {
		return employees;
	}
	public void setEmployees(List<EmployeeBean> employees) {
		this.employees = employees;
	}

	public void display(){
		System.out.println("SBU Details");
		System.out.println("------------------------------------");
		System.out.println("sbu details=SBU sbuCode= "+sbuCode +"sbuHead= "+ sbuHead+"sbuName= "+sbuName);
		for(EmployeeBean e:employees){
			System.out.println("empAge= "+e.getAge()+" empId= "+ e.getEmployeeId()+" empName= "+e.getEmployeeName()+" empSalary= "+e.getSalary() );
		}
	}
}
