package com.cg.sbu;

import org.springframework.context.support.ClassPathXmlApplicationContext;



public class SBUTest {
	public static void main(String[] args) {
		ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("spring.xml");
		SBUBean emp=(SBUBean)ctx.getBean("sbu");
		
		emp.display();
		ctx.close();
	}

}
