package com.cg.employee;

public class EmployeeBean {
	private int age; 
	private int id;
	private String name;
	private double salary;
	private SBUBean businessUnit;
	
	
	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public SBUBean getBusinessUnit() {
		return businessUnit;
	}

	public void setBusinessUnit(SBUBean businessUnit) {
		this.businessUnit = businessUnit;
	}

	public void display(){
		System.out.println("Employee Details");
		System.out.println("------------------------------------");
		System.out.println("Employee Age:"+age+"Employee Id:"+id+"Employee Name:"+name+"Employee Salary:"+salary);
		System.out.println("sbu details=SBU sbuCode="+businessUnit.getSbuId() +"sbuHead="+ businessUnit.getSbuHead()+"sbuName="+businessUnit.getSbuName());
		
	}

}
