package com.cg.employee;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class EmployeeTest {
	public static void main(String[] args) {
		ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("spring1.xml");
		EmployeeBean emp=(EmployeeBean)ctx.getBean("employee");
		
		emp.display();
		ctx.close();
	}

}
