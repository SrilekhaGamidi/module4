package com.cg.service;

import com.cg.bean.TraineeBean;

public interface ITraineeService {
	  public TraineeBean addTrainee(TraineeBean traineeBean);

}
