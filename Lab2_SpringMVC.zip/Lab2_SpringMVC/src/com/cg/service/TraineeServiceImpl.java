package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.TraineeBean;
import com.cg.dao.ITraineeDao;

@Service
public class TraineeServiceImpl implements ITraineeService {
	
	@Autowired
	ITraineeDao traineeDao;

	@Override
	public TraineeBean addTrainee(TraineeBean traineeBean) {
		
		return traineeDao.addTrainee(traineeBean);
	}

}
