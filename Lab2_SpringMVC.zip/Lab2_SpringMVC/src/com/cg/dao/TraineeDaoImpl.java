package com.cg.dao;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.cg.bean.TraineeBean;

@Repository
public class TraineeDaoImpl implements ITraineeDao {

	
	Map<Integer,TraineeBean> map = new HashMap<Integer,TraineeBean>();

	@Override
	public TraineeBean addTrainee(TraineeBean traineeBean) {
		map.put(traineeBean.getTraineeId(), traineeBean);
		
		return traineeBean;
	}
	
}
