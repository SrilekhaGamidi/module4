package com.cg.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.bean.TraineeBean;

public interface ITraineeDao {

  public TraineeBean addTrainee(TraineeBean traineeBean);	
	
}
