package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.bean.TraineeBean;
import com.cg.service.ITraineeService;


@Controller
public class TraineeController {

	@Autowired
	ITraineeService traineeService;
	@RequestMapping("show")
	public String showHomePage()
	{
		return("index");
	}
	@RequestMapping("add")
	public String add(){
		return("addTrainee");
	}
	
	
	@RequestMapping(value="addTrainee",method=RequestMethod.POST)
	public String addEmployee(@ModelAttribute("trainee") TraineeBean bean,BindingResult result,Model model)
	{
		if(result.hasErrors())
		{
			model.addAttribute("message", result);
			return("error");
		}
		return("success");
	}
	
	

}
