package com.cg.bbok;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

public class Client4 {
	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
				
		TypedQuery<Book> qry=em.createQuery("from Book where bookId=?", Book.class);
		qry.setParameter(1,4);
				
		Book book=qry.getSingleResult();
		
			for(Author author:book.getAuthors())
			{
			System.out.println(author.getAuthorId()+" "+author.getAuthorName());
		}
			em.getTransaction().commit();
			System.out.println("Books Info");
			em.close();
			factory.close();
		

}

}
