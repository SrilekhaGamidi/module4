package com.cg.bbok;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

public class Client1 {
	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		
		
		String qryStr="from Book";
		TypedQuery<Book> qry=em.createQuery(qryStr, Book.class);
		List<Book> list=qry.getResultList();
		for(Book book:list){
			System.out.println(book.getBookId()+" "+book.getPrice()+" "+book.getTitle());
		}
		
		em.getTransaction().commit();
		System.out.println("Books Info");
		em.close();
		factory.close();

	}


}
