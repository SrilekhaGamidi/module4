package com.cg.bbok;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

public class Client3 {
	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		TypedQuery<Book> qry=em.createQuery("from Book where price BETWEEN 500 AND 1000", Book.class);
			
		
		List<Book> list=qry.getResultList();
		for(Book book:list){
			System.out.println(book.getBookId()+" "+book.getPrice()+" "+book.getTitle());
		}
		
		em.getTransaction().commit();
		System.out.println("Books Info");
		em.close();
		factory.close();

}
}
