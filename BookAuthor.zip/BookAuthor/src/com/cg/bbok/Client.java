package com.cg.bbok;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

public class Client {
	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		
		
		Book b1=new Book();
		
		b1.setPrice(1000);
		b1.setTitle("Harry Potter");
		
		Book b2=new Book();
		
		b2.setPrice(3000);
		b2.setTitle("Twilight");
		
		Book b3=new Book();
		
		b3.setPrice(5000);
		b3.setTitle("Sherlock Holmes");
		
		
		Author a1=new Author();
		
		a1.setAuthorName("Stephen Mayer");
		
		Author a2=new Author();
		
		a2.setAuthorName("JK Rowling");
		
		Author a3=new Author();
		
		a3.setAuthorName("Chethan Bhagath");
		
		b1.addAuthor(a1);
		b1.addAuthor(a3);
		
		b2.addAuthor(a3);
		b2.addAuthor(a2);
		
		b3.addAuthor(a1);
		b3.addAuthor(a2);
		
		em.persist(b1);
		em.persist(b2);
		em.persist(b3);
		
		
		
		em.getTransaction().commit();
		System.out.println("successfully added");
		em.close();
		factory.close();

	}

}
