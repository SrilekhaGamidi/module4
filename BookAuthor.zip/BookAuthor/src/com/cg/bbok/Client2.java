package com.cg.bbok;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

public class Client2 {
	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
				
		TypedQuery<Author> qry=em.createQuery("from Author where authorName=?", Author.class);
		qry.setParameter(1,"Stephen Mayer");
				
		Author author=qry.getSingleResult();
		
			for(Book book:author.getBooks())
			{
			System.out.println(book.getBookId()+" "+book.getPrice()+" "+book.getTitle());
		}
			em.getTransaction().commit();
			System.out.println("Books Info");
			em.close();
			factory.close();
		

}
}
