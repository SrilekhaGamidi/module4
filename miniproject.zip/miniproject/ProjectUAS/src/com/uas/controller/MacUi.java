package com.uas.controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.uas.bean.ApplicantBean;
import com.uas.bean.UserRole;
import com.uas.dao.IMacDAO;
import com.uas.dao.MacDaoImpl;
import com.uas.exception.CustomException;
import com.uas.service.IMacService;
import com.uas.service.MacServiceImpl;

public class MacUi {

	public static void main(String[] args) throws CustomException, SQLException {
		
		int method=0;
		boolean success = false;
		String role = null;
		String userId = null;
		String pass = null;
	
		System.out.println("1.Login\n2.View Applications\n3.Update Status");
		
		
		Scanner sc = new Scanner(System.in);
	
		
		method = sc.nextInt();
		
		if(method == 1){
		
		   System.out.println("Enter User type(mac,admin)");
	       role = sc.next();
	       role = role.toLowerCase();
	       if(role.equals("mac") || role.equals("admin")){
	    	   System.out.println("Enter User id");
	    	   userId = sc.next();
		
	    	   System.out.println("Enter User pass");
	    	   pass = sc.next();

		
	    	   IMacService macService = new MacServiceImpl();
	
	    	   success = macService.isAuthenticated(userId, pass, role);
		
		
			
	    	   if(success == true)
	    		   System.out.println("found");
	    	   else{	
	    		   System.out.println("not found");
	    	   }
	       }
		}else if(method == 2){
		
			System.out.println("Enter program Id\n");
		
		    String progId = sc.next();
				
		    List<ApplicantBean> list = new ArrayList<ApplicantBean>();
		    IMacService macService = new MacServiceImpl();
			
			list = macService.viewAllStudentDetails(progId);
				
			for(ApplicantBean ab : list ){
				System.out.println(ab.getApplicationId());
					
			}
		
		}else if(method == 3){
			boolean updated = false;
			System.out.println("Enter application id\n");
			int applicationId = sc.nextInt();
			System.out.println("Enter the status for id "+applicationId);
			String status = sc.next();
		
			IMacService macService = new MacServiceImpl();
		
			updated = macService.updateStatus(applicationId, status);
			
			if(updated == true){
				System.out.println("updated");
			}else{
				System.out.println("could not update");
			}
		}
	}
		

}


