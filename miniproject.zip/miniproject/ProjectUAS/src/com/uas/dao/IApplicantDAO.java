package com.uas.dao;

import java.util.List;

import com.uas.bean.ApplicantBean;
import com.uas.bean.Application_Status;
import com.uas.exception.CustomException;

public interface IApplicantDAO {
	public List<Object> viewPrograms() throws CustomException;
	public boolean insertApplicant(ApplicantBean applicantBean) throws CustomException;
	public Application_Status viewStatus(int applicantId) throws CustomException;
}
