/*package com.uas.dao;

import java.util.List;

import com.uas.bean.ApplicantBean;
import com.uas.bean.Application_Status;
import com.uas.exception.ApplicantException;

public class ApplicantDAOImpl implements IApplicantDAO {

	@Override
	public List<Object> viewPrograms() throws ApplicantException {
		try{}
		return null;
	}

	@Override
	public boolean insertApplicant(ApplicantBean applicantBean)
			throws ApplicantException {
		
		return false;
	}

	@Override
	public Application_Status viewStatus(int applicantId)
			throws ApplicantException {
		
		return null;
	}

}
*/