package com.uas.dao;

public interface AdminQueryMapper {
	public static final String IS_AUTHENTICATED="";
	
	//PROGRAMS OFFERED
	public static final String DELETE_PROGRAM_OFFERED = "";
	public static final String ADD_PROGRAM_OFFERED ="";
	
	//PROGRAMS SCEHDULED
	public static final String DELETE_PROGRAM_SCHEDULED = "";
	public static final String ADD_PROGRAM_SCHEDULED = "";
	public static final String VIEW_PROGRAM_SCHEDULED = "";
	
	//APPLICANTS
	public static final String VIEW_APPLICANTS = "";
}