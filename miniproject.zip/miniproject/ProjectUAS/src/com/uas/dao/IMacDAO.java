package com.uas.dao;

import java.sql.SQLException;
import java.util.List;

import com.uas.bean.ApplicantBean;
import com.uas.bean.UserRole;
import com.uas.exception.CustomException;


public interface IMacDAO {
	
	public boolean isAuthenticated(String loginId, String pass, String role) throws CustomException, SQLException;
	
	//view applicant list for specific programs offered
	public List<ApplicantBean> viewListOfApplicants(String Scheduled_program_id) throws CustomException, SQLException;
	
	//update status of applicant
	public boolean updateStatus(int Application_Id, String status) throws CustomException , SQLException;

}