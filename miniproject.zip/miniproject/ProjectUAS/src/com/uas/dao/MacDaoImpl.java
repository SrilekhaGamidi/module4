package com.uas.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;



import com.uas.bean.ApplicantBean;
import com.uas.bean.UserBean;
import com.uas.bean.UserRole;
import com.uas.exception.CustomException;
import com.uas.util.DBConnection;
import com.uas.util.DBConnection;

public class MacDaoImpl implements IMacDAO {

	@Override
	public boolean isAuthenticated(String loginId, String pass, String role0)
			throws CustomException, SQLException {
		boolean found=false;
		try{
			
			
			Connection con = null;
			
			DBConnection.getInstance();
			con = DBConnection.getConnection();
			
			PreparedStatement pstmt = con.prepareStatement(MacQueryMapper.IS_AUTHENTICATED);
			java.sql.ResultSet rst = pstmt.executeQuery();
			
			while (rst.next()){
				String login1 = rst.getString("login_id");
			    String pass1 = rst.getString("password");
			    String role1 = rst.getString("role");
			    if(role0.equals(role1)){
			    	
					if(loginId.equals(login1))
					{
						if(pass.equals(pass1)){
							found=true;
						}
					}
			    	
			    
			}
			
				
			}
			    
			
			}catch (CustomException ce){
				ce.printStackTrace();
			}catch (SQLException se){
				se.printStackTrace();
			}
			
		
		
		return found;
	}

	@Override
	public List<ApplicantBean> viewListOfApplicants(String Scheduled_program_id)
			throws CustomException, SQLException {
		
		List<ApplicantBean> list = new ArrayList<ApplicantBean>() ;
		
		try{
			
		Connection con = null;
		
		DBConnection.getInstance();
		con = DBConnection.getConnection();
		
		PreparedStatement pstmt = con.prepareStatement(MacQueryMapper.VIEW_APPLICANTS);
		pstmt.setString(1, Scheduled_program_id);
		java.sql.ResultSet rst = pstmt.executeQuery();

		while (rst.next()){
			ApplicantBean bean = new ApplicantBean();
			bean.setApplicationId(rst.getInt(1));
			list.add(bean);
		}
		if(list==null){
			throw new CustomException(message)
		}
		
		con.close();
		
		}catch (SQLException se){
			throw new CustomException("In DAO Layer viewAll method"+se.getMessage());
		}catch (CustomException ce){
			throw new CustomException("In DAO Layer viewAll method"+ce.getMessage());
		}
		
		return list;
	}

	@Override
	public boolean updateStatus(int Application_Id, String status) throws CustomException, SQLException {
		
		boolean updated=false;
		try{
        Connection con = null;
		
		DBConnection.getInstance();
		con = DBConnection.getConnection();
		
		PreparedStatement pstmt = con.prepareStatement(MacQueryMapper.UPDATE_STATUS);
		pstmt.setInt(2, Application_Id);
		pstmt.setString(1, status);
		java.sql.ResultSet rst = pstmt.executeQuery();
		if(rst.next())
		{
		updated = true;
		}
		
		}catch (SQLException se){
			throw new CustomException("No such Id");
		}catch (CustomException ce){
			throw new CustomException("Couldnt update status. Exception In DAO Layer viewAll method"+ce.getMessage());
		}
		return updated;
	}

}
