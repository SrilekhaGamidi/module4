package com.uas.bean;

public class ParticipantBean {
	private int rollNo;
	private String emailId;
	public ParticipantBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ParticipantBean(int rollNo, String emailId) {
		super();
		this.rollNo = rollNo;
		this.emailId = emailId;
	}
	
	public int getRollNo() {
		return rollNo;
	}
	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	@Override
	public String toString() {
		return "ParticipantBean [rollNo=" + rollNo + ", emailId=" + emailId
				+ "]";
	}
	
}
