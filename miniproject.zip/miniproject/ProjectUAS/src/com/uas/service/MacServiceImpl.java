package com.uas.service;

import java.sql.SQLException;
import java.util.List;

import com.uas.bean.ApplicantBean;
import com.uas.bean.UserRole;
import com.uas.dao.IMacDAO;
import com.uas.dao.MacDaoImpl;
import com.uas.exception.CustomException;


public class MacServiceImpl implements IMacService {

	private IMacDAO macDao = new MacDaoImpl();
	
	@Override
	public boolean isAuthenticated(String loginId, String pass2, String role2)
			throws CustomException, SQLException {
		
		return macDao.isAuthenticated(loginId, pass2, role2);
				
	}

	@Override
	public List<ApplicantBean> viewAllStudentDetails(String Scheduled_program_id) throws CustomException,
			SQLException {
		
		return macDao.viewListOfApplicants(Scheduled_program_id);
	}

	@Override
	public boolean updateStatus(int Application_Id, String status)
			throws CustomException, SQLException {
		
		return macDao.updateStatus(Application_Id, status);
	}

}
